Viaoda Libre is a display family inspired by Vietnamese cultural symbolism. Its design feels traditional yet it features some modern elements. Viaoda Libre works well in large titles and subtitles.

We're actively working on the family. We hope to improve the Vietnamese in future releases.

Contact at [gydient.com](https://gydient.com)  
Contribute at [github.com/bettergui/ViaodaLibre](https://github.com/bettergui/ViaodaLibre)